---
title: "rstudio::conf 2020"
date: "2020-01-27"
date_end: "2020-01-30"
publishDate: "2019-02-27"
announce: true
description: >
  The conference for all things R and RStudio.
event_url: "https://www.rstudio.com/conference/"
location: "San Francisco, CA"
educators:
  - Mine
  - Garrett
  - Greg
  - Carl
  - Alison
photo:
  url: https://unsplash.com/photos/f9TWR57Uujo
  author: Pedro Lastra
---

rstudio::conf 2020 covers all things RStudio, including workshops to teach you the tidyverse, and talks to show you the latest and greatest features.
