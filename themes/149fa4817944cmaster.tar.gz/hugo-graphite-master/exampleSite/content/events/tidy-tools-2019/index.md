---
title: "Building Tidy Tools"
date: "2019-05-01"
date_end: "2019-05-02"
publishDate: "2019-02-27"
announce: true
description: >
  This workshop, taught by [Hadley Wickham](http://hadley.nz/), is for people who have experience programming in R and want to learn how to tackle larger scale problems. 
event_url: "https://www.rstudio.com/conference/"
location: "Sydney, Australia"
educators:
  - Hadley Wickham
---

The class is taught by Hadley Wickham, Chief Scientist at RStudio.
