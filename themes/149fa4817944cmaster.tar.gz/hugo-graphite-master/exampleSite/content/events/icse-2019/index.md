---
title: "ICSE 2019"
date: "2019-05-28"
date_end: ""
publishDate: "2019-02-27"
announce: true
description: >
  One-day workshop for software engineering researchers attending ICSE conference.
event_url: "https://www.rstudio.com/conference/"
location: "Montréal, PQ, Canada"
educators: 
  - Greg
---

