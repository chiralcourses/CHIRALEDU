---
title: "Education @ RStudio"
col0:
  row1: "dplyr"
  row2: "ggplot2"
  row3: "readr"
col1:
  row2: "forcats"
  row3: "stringr"
col2:
  row2: "tibble"
  row3: "tidyr"
  row4: "purrr"
---

Our mission is to equip everyone, regardless of means, to participate in a global economy that rewards data literacy.
