---
title: "Need help?"
image: "images/bee1.jpg"
---

First learn how to make a [reprex](/help/#reprex) then [share it](/help/#where-to-ask) with others.

   
