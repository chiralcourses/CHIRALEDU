---
title: "Learn the tidyverse"
image: cover.png
alt_text: "R for Data Science book cover"
url_image: http://amzn.to/2aHLAQ1
---

See how the tidyverse makes data science faster, easier and more fun with "R for Data Science". Read it [online](http://r4ds.had.co.nz/), buy [the book](http://amzn.to/2aHLAQ1) or try another [resource](/learn/) from the community.
   
