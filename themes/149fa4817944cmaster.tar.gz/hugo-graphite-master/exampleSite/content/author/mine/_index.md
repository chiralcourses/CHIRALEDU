---
name: Mine Çetinkaya-Rundel
photo: 'https://github.com/mine-cetinkaya-rundel.png'
social:
  github: 'mine-cetinkaya-rundel'
  twitter: "minebocek"
  website: "http://mine-cr.com/"
description: Data Scientist and Professional Educator
team: true
---

likes :kissing_cat:, will :airplane:
