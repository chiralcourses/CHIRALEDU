---
name: Garrett Grolemund
photo: 'https://github.com/garrettgman.png'
social:
  github: 'garrettgman'
  twitter: "StatGarrett"
  website: ""
description: Data Scientist and Master Instructor 
team: true
---

Bio goes here
