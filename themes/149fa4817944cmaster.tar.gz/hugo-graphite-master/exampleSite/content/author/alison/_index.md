---
name: Alison Hill
photo: 'https://github.com/apreshill.png'
social:
  github: 'apreshill'
  twitter: "apreshill"
  website: "https://alison.rbind.io/"
description: Data Scientist and Professional Educator 
team: true
---

Bio goes here
