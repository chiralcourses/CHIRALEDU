---
name: Greg Wilson
photo: 'http://third-bit.com/files/gvwilson-tpl-2017-small.jpg'
social:
  github: 'gvwilson'
  twitter: "gvwilson"
  website: "http://third-bit.com/"
description: Data Scientist and Professional Educator
team: true
---

Bio goes here
